﻿# 30 组基准数据集 (baseline reference pack)

导出时间: 2026-10-16 22:43:05
平台: AMD TR PRO 5975WX + RTX 4070 Ti SUPER 16GB + 4x32GB DDR4-3200
引擎: llama.cpp b11617 (commit 14310190c) / Clang 20.1.8

## 内容

  qwen3-next-80b-a3b/   30 组 (G01-G30)  Qwen3-Next-80B-A3B-Instruct-Q4_K_M
  gpt-oss-120b/         30 组 (G01-G30)  gpt-oss-120b-MXFP4
  MANIFEST.csv          两组全部 60 组的配置与结果一览

## 每组包含的完整文件

  RESULT.md              已解析的结果摘要
  raw/meta.json          启动参数、线程数、掩码等
  raw/run-summary.json   3 遍中位、极差
  raw/runs.jsonl         逐遍原始记录 (prompt_n / predicted_n / 生成文本片段)
  raw/samples.jsonl      逐秒采样 (功耗/VRAM/每核占用)
  raw/sample-stats.json  上述采样的统计摘要
  raw/server.log         llama.cpp 完整日志 (含权重账本、MoE cache 行)
  raw/weights.json       权重账本解析
  raw/tensors.txt        张量块大小
  raw/sched.txt          调度图信息

## 重要说明（作为基准参照时必须知道）

1. 这两批数据用旧版嵌套掩码（含 SMT），组间对照干净，但绝对性能偏低。
   80B 用无 SMT 物理核掩码可再快 21%；120B 重扫后 18.02 -> 22.339 t/s (+24%)。
   无 SMT 的 120B 重扫见 smt-fix-120b/（不在本包内）。
2. 本包不含 MoE cache 命中率——b11617 不输出该日志行。
3. 各组 decode 为 3 遍取中位；首遍系统性偏低 50-100%。噪声底 ±1.8%。
4. 权重账本逐组闭合：80B = 47749.5 MiB，120B = 62328.3 MiB。

